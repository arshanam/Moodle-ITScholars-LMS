﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using getUserCredential;
using getUserCredential.SRCredentials2;

namespace getUserCredential
{
    class UserCredential
    {
        getUserCredential.SRCredentials2.CredentialsClient GUC;

        private XmlDocument xmldoc;
        private String _username;
        private String _password;
        private String _ipAddress;
        private String _filename;
        private String _error;

        public UserCredential(){
            GUC = new getUserCredential.SRCredentials2.CredentialsClient();
        }

        protected String username
        {
            get { return _username; }
            set { _username = value; }
        }

        protected String password
        {
            get { return _password; }
            set { _password = value; }
        }

        protected String ipAddress
        {
            get { return _ipAddress; }
            set { _ipAddress = value; }
        }

        protected String filename
        {
            get { return _filename; }
            set { _filename = value; }
        }

        protected String error
        {
            get { return _error; }
            set { _error = value; }
        }

        protected void createXMLfile()
        {

            XmlNode xmlnode;
            XmlElement xmlelem;
            XmlText xmltext;

            this.xmldoc = new XmlDocument();
            xmlnode = xmldoc.CreateNode(XmlNodeType.XmlDeclaration,"","");
            this.xmldoc.AppendChild(xmlnode);

            //Credential Element
            xmlelem = xmldoc.CreateElement("","Credential","");
            this.xmldoc.AppendChild(xmlelem);

            //child of the Credential
            xmlelem = xmldoc.CreateElement("","username","");
            xmltext = xmldoc.CreateTextNode(this.username);
            xmlelem.AppendChild(xmltext);
            this.xmldoc.ChildNodes.Item(1).AppendChild(xmlelem);

            //2nd child of the Credential
            xmlelem = xmldoc.CreateElement("", "password", "");
            xmltext = xmldoc.CreateTextNode(this.password);
            xmlelem.AppendChild(xmltext);
            this.xmldoc.ChildNodes.Item(1).AppendChild(xmlelem);
            
            //save the XML document in a file
            try{
                this.xmldoc.Save(this.filename + ".xml");
                Console.WriteLine("Completed: " + this.filename + ".xml was created");
            }
            catch (Exception e){
                Console.WriteLine("Failed: " + e.Message);
            }
        }

        protected void getUserInfo(string ipaddress)
        {
            string pass, user, error;

            user = GUC.getUserCredential(ipaddress, out pass, out error);

            this.username = user;
            this.password = pass;
            this.error = error;
        }

        static void Main(string[] args)
        {
            getUserCredential.UserCredential uc = new getUserCredential.UserCredential();

            if (args.Length > 1)
            {
                uc.filename = args[1];  // <filename>.xml
                uc.ipAddress = args[0]; // ita-exchange.cis.fiu.edu
                uc.getUserInfo(uc.ipAddress);

                Console.WriteLine(uc.error);
                //Console.WriteLine("{0}", args[0]);
                uc.createXMLfile();
            }
            else
            {
                Console.WriteLine("No filename arguement.");
            }
        }
    }
}
